function quantoFaltaPara(m, d) {


}
