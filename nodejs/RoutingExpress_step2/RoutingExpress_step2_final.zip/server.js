const app = require('./src/app')

app.listen(3001)